export const appointmentsNamespace = "appointments";
