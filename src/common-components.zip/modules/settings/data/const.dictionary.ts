export const dictionary = {
	hourlyRate: "hourlyRate",
	currencySymbol: "currencySymbol",
	module_prescriptions: "module_prescriptions",
	module_orthodontics: "module_prescriptions",
	module_endodontics: "module_endodontics",
	module_statistics: "module_statistics",
	time_tracking: "time_tracking",
	backup_freq: "backup_freq",
	backup_retain: "backup_retain",
	dropbox_accessToken: "dropbox_accessToken",
	lang: "lang",
	date_format: "date_format",
	weekend_num: "weekend_num"
};
