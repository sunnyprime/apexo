export const settingsNamespace = "settings";
