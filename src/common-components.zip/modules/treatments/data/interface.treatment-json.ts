export interface TreatmentJSON {
	_id: string;
	type: string;
	expenses: number;
}
