export const orthoNamespace = "orthodontic";
