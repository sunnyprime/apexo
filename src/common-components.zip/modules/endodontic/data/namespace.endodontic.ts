export const endoNamespace = "endodontic";
