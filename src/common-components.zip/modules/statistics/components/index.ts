export * from "./chart.age";
export * from "./chart.appointments-date";
export * from "./chart.finance";
export * from "./chart.gender";
export * from "./chart.most-applied-treatments";
export * from "./chart.most-involved-teeth";
export * from "./chart.treatments-gender";
export * from "./chart.treatments-number";
