export interface ProceduresJSON {
    _id: string;
    patientid: string;
	done: string;
	date: string;
	priority: number;
	tooth: number;
	desc: string;
	fees: string;
	discount: string;
	fdiscount: string;
	insurance: string;
	psignature: string;
	
}
