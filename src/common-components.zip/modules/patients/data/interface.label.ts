import { TagType } from "@common-components";

// patient labels interface
export interface Label {
	type: TagType;
	text: string;
}
