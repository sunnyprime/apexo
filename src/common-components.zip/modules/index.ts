// ^ dynamically imported (code-splitting) styles

export * from "./appointments";
export * from "./orthodontic";
export * from "./endodontic";
export * from "./patients";
export * from "./prescriptions";
export * from "./settings";
export * from "./staff";
export * from "./statistics";
export * from "./treatments";
export * from "./register-modules";
