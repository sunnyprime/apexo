export function round(n: number) {
	return Math.round(n * 100) / 100;
}
