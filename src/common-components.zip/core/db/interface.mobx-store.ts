import { IClassStatic } from "./interface.class-static";

export interface IMobXStore {
	ignoreObserver: boolean;
	list: IClassStatic[];
}
