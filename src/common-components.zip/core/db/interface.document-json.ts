export interface IDocumentJSON {
	_id: string;
}
