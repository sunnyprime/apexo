interface DatabasesConfig {
	[key: string]: {
		shouldLog: boolean;
	};
}

export const configs: DatabasesConfig = {};
